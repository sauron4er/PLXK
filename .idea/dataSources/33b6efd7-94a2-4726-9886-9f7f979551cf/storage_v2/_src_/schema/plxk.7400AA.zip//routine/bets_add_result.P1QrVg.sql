CREATE PROCEDURE bets_add_result(IN team1result INT, IN team2result INT, IN matchid INT)
  BEGIN
	UPDATE bets_match SET
   team1_result = team1result, team2_result = team2result, match_status = 1
   WHERE id = matchid;
END;

