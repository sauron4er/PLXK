CREATE VIEW bets_view_bets AS
  SELECT
    `b`.`id`                                       AS `id`,
    concat(`u`.`last_name`, ' ', `u`.`first_name`) AS `player`,
    concat(`t1`.`name`, ' - ', `t2`.`name`)        AS `match`,
    concat(`b`.`team1_bet`, ':', `b`.`team2_bet`)  AS `bet`
  FROM ((((`plxk`.`bets_bet` `b`
    JOIN `plxk`.`auth_user` `u` ON ((`b`.`player_id` = `u`.`id`))) JOIN `plxk`.`bets_match` `m`
      ON ((`b`.`match_id` = `m`.`id`))) JOIN `plxk`.`bets_team` `t1` ON ((`m`.`team1_id` = `t1`.`id`))) JOIN
    `plxk`.`bets_team` `t2` ON ((`m`.`team2_id` = `t2`.`id`)))
  WHERE (`m`.`match_status` = 0);

