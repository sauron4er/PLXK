CREATE VIEW questions AS
  SELECT
    `q`.`question_text` AS `question_text`,
    `q`.`question_type` AS `question_type`,
    count(`uc`.`id`)    AS `count(uc.id)`
  FROM (`plxk`.`polls_question` `q` LEFT JOIN `plxk`.`polls_user_choice` `uc` ON ((`q`.`id` = `uc`.`question_id`)))
  GROUP BY 1, 2;

