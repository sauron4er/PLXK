CREATE PROCEDURE bets_calc_points(IN in_matchid INT)
  BEGIN
	DECLARE done INT DEFAULT 0;
	DECLARE t1, t2 INT;
	DECLARE b1, b2, bid INT;
	DECLARE new_points INT DEFAULT 0;	
	DECLARE cursor1 CURSOR FOR select bb.team1_bet, bb.team2_bet, bb.id
         							from bets_bet bb
         							where bb.match_id = in_matchid;
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

	/* Підтягуємо результати матчу */
	select bm.team1_result, bm.team2_result    
	from bets_match bm
	where bm.id = in_matchid
	into t1, t2;

	/* рахуємо зароблені бали */
	OPEN cursor1;

	REPEAT
		FETCH cursor1 INTO b1, b2, bid;		
		
		if (((t1 > t2) and (b1 > b2)) or ((t1 < t2) and (b1 < b2))) then 
		  	set new_points = new_points + 5;
     	end if;
     	
     	     	       	
		if (t1 = b1) then
		    set new_points = new_points + 1;
		end if;
		
		if (t2 = b2) then
		    set new_points = new_points + 1;
		end if;
		
		if ((t1 - t2) = (b1 - b2)) then
         set new_points = new_points + 3;
		end if;
					    
		
		if ((t1 = t2) and (b1 = b2)) then
			set new_points = new_points + 5;		
		        		
        	if (abs(t1 - b1) > 1) then
            set new_points = new_points -2;
         end if;		    
		
		end if;
		
		UPDATE bets_bet bb set points = new_points where bb.id = bid;
		set new_points = 0;
	    
	    
	UNTIL done END REPEAT;

	CLOSE cursor1;
            
END;

