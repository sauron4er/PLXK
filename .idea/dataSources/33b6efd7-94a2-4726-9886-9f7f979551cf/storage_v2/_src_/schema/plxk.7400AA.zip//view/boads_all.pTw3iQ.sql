CREATE VIEW boads_all AS
  SELECT
    `b`.`id`                            AS `id`,
    `b`.`name`                          AS `name`,
    `b`.`description`                   AS `description`,
    (SELECT count(0)
     FROM `plxk`.`boards_topic` `t`
     WHERE (`t`.`board_id` = `b`.`id`)) AS `topics`,
    (SELECT count(0)
     FROM (`plxk`.`boards_post` `p` LEFT JOIN `plxk`.`boards_topic` `t` ON ((`p`.`topic_id` = `t`.`id`)))
     WHERE (`t`.`board_id` = `b`.`id`)) AS `posts`
  FROM `plxk`.`boards_board` `b`;

