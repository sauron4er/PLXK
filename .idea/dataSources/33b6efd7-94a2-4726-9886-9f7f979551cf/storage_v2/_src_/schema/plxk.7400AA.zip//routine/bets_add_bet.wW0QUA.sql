CREATE PROCEDURE bets_add_bet(IN playerid INT, IN matchid INT, IN team1bet INT, IN team2bet INT)
  BEGIN
	INSERT INTO bets_bet (player_id, match_id, team1_bet, team2_bet)
	VALUES (playerid, matchid, team1bet, team2bet)
	ON DUPLICATE KEY UPDATE player_id = playerid, match_id = matchid;
END;

