CREATE FUNCTION bets_get_current_season()
  RETURNS INT
  BEGIN
	declare last_season_id int;
	select id from bets_season
	where CURDATE() between season_begin and season_end
	into last_season_id;
	
	
	return last_season_id;
END;

