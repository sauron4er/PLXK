CREATE TRIGGER bets_match_au_calc_points
  AFTER UPDATE
  ON bets_match
  FOR EACH ROW
  BEGIN
	/*procedure bets_calc_points (in new.id);*/
	call `bets_calc_points` (new.id);
END;

